package contest_oop.b1;

import java.util.Scanner;

public class Run {

  public static void main(String[] args) {
    Scanner scan = new Scanner(System.in);
    int n = scan.nextInt();
    while (n-- > 0) {
      double x1 = scan.nextDouble();
      double y1 = scan.nextDouble();

      Point point1 = new Point(x1, y1);
      double x2 = scan.nextDouble();
      double y2 = scan.nextDouble();

      System.out.println(String.format("%.4f",point1.distance(new Point(x2, y2))));
    }
  }
}
