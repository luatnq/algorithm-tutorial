package oop.j07007;

import oop.j07007.WordSet;

import java.io.IOException;

public class Run {
  public static void main(String[] args) throws IOException {
    WordSet ws = new WordSet("VANBAN.in");
    System.out.println(ws);
  }
}
