package oop.j04003;

import java.util.Scanner;

public class Main {

  public static void main(String[] args) {
    Scanner scan = new Scanner(System.in);
    int a = scan.nextInt(), b = scan.nextInt();
    int n = gcd(a, b);
    if (n == 0){
      PhanSo phanSo = new PhanSo(a, b);
      System.out.println(phanSo);
    }else{
      PhanSo phanSo = new PhanSo(a/n, b/n);
      System.out.println(phanSo);
    }

  }

  private static int gcd(int a, int b) {
    while (b != 0) {
      int t = b;
      b = a % b;
      a = t;
    }
    return a;
  }
}
