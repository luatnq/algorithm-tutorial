package oop.j04003;

public class PhanSo {

  private Integer tuSo;
  private Integer mauSo;

  public PhanSo() {
  }

  public PhanSo(Integer tuSo, Integer mauSo) {
    this.tuSo = tuSo;
    this.mauSo = mauSo;
  }

  public Integer getTuSo() {
    return tuSo;
  }

  public void setTuSo(Integer tuSo) {
    this.tuSo = tuSo;
  }

  public Integer getMauSo() {
    return mauSo;
  }

  public void setMauSo(Integer mauSo) {
    this.mauSo = mauSo;
  }

  @Override
  public String toString() {
    return tuSo + "/" + mauSo;
  }
}
